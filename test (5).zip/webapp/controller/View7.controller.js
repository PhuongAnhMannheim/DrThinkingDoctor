sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"test/controller/CustomLayout"
], function (Controller, CustomLayout) {
	var oPageController = Controller.extend("test.controller.View7", {
		onInit: function () {
			var oGraph = this.byId("graph");

			oGraph.setLayoutAlgorithm(new CustomLayout());
		}
	});
	return oPageController;
});