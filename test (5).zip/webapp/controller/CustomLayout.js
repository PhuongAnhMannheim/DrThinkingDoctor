sap.ui.define([
	"sap/suite/ui/commons/networkgraph/layout/LayoutAlgorithm",
	"sap/suite/ui/commons/networkgraph/layout/LayoutTask"
], function (LayoutAlgorithm, LayoutTask) {
	return LayoutAlgorithm.extend("test.controller.CustomLayout", {
		isLayered: function () {
			return true;
		},
		layout: function () {
			return new LayoutTask(function (fnResolve, fnReject, oLayoutTask) {
				// The task might have been canceled by a newer update call. Do not update graph as it might collide
				// with another layout task.
				if (oLayoutTask.isTerminated()) {
					fnResolve();
					return;
				}

				var oGraph = this.getParent(),
					aNodes = oGraph.getNodes(),
					aLines = oGraph.getLines(),
					oNode1Center, oNode2Center, oNode3Center,oNode4Center,oNode5Center;

				aNodes[0].setX(30);
				aNodes[0].setY(150);

				aNodes[1].setX(450);
				aNodes[1].setY(60);

				aNodes[2].setX(450);
				aNodes[2].setY(120);
				
				aNodes[3].setX(450);
				aNodes[3].setY(180);
				
				aNodes[4].setX(450);
				aNodes[4].setY(240);

				oNode1Center = aNodes[0].getCenterPosition();
				oNode2Center = aNodes[1].getCenterPosition();
				oNode3Center = aNodes[2].getCenterPosition();
                oNode4Center = aNodes[3].getCenterPosition();
                oNode5Center = aNodes[4].getCenterPosition();
				// !IMPORTANT
				// don't use direct aggregation methods in this function (like addCoordinate) as it would
				// trigger invalidate to the graph and throw code in the never ending loop (as line is not rendered yet
				// and invalidate throws invalidation to its parent).
				// these methods does not trigger invalidate.
				aLines[0].setSource({
					x: oNode1Center.x,
					y: oNode1Center.y
				});

				aLines[0].setTarget({
					x: oNode2Center.x,
					y: oNode2Center.y
				});

				// !IMPORTANT
				// before adding bends you have to add target and source
				

				// second line
				// by default you should use rectangular bend line but graph can display this one too
				// you have to take care of arrow position tho
				// either by setting it to the middle (this case) or by moving end (start) of the line
				aLines[1].setSource({
					x: oNode1Center.x,
					y: oNode1Center.y
				});

				aLines[1].setTarget({
					x: oNode3Center.x,
					y: oNode3Center.y
				});
				
				aLines[2].setSource({
					x: oNode1Center.x,
					y: oNode1Center.y
				});

				aLines[2].setTarget({
					x: oNode4Center.x,
					y: oNode4Center.y
				});
				
				aLines[3].setSource({
					x: oNode1Center.x,
					y: oNode1Center.y
				});

				aLines[3].setTarget({
					x: oNode5Center.x,
					y: oNode5Center.y
				});

				fnResolve();
			}.bind(this));
		}
	});
});